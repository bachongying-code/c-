#include"stdio.h"
int main()
{
    int a ,b;
    a = 1000 / 60;
    b = 1000 % 60;
    printf("%d %d", a, b);






} 
