#include "stdio.h"
int main()
{
	char a;
	scanf_s("%c", &a);
	printf("%d/n", a-96);
	return 0;
}