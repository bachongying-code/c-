#include"stdio.h"
int main()
{
	double a;
	scanf_s("%lf", &a);
	a = 1.0 * (int)(a * 100 + 0.5) / 100;
	printf("%lf", a);
	return 0;




}