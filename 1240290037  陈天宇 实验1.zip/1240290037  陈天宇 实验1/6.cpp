#include "stdio.h"
int main()
{
	double a=0.0, b=0.0, c=0.0;
	scanf_s("%lf %lf %lf",&a,&b, &c);
	printf("%.2lf", (a + b + c) /3.0);
	return 0;





}