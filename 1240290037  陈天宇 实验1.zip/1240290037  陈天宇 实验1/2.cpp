#include "stdio.h"
int main()
{
	char a;
	scanf_s ("%c",&a);
	a = (a+4)%122+96;

	
	printf ("%c", a);





}