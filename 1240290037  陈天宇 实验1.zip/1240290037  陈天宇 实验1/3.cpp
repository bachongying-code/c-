#include "stdio.h"
int main()
{
	char F, C;
	scanf_s("%d", &F);
	C = 5.0 / 9 * (F - 32);
	printf("%d", C);



}